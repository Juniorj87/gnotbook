GNO PUNK — editions 1001-1111 (archive)

These 111 editions are NOT part of the published 1,000-edition collection.
They are kept here because the current Octopin Free plan allows 2,000 files,
and the published drop already uses exactly 2,000 files (1,000 images + 1,000 JSON).

Do not upload this archive to the collection directories. To publish a larger
collection, upgrade Octopin (Hobby and above allow 50,000 files), rebuild the
metadata with `node scripts/build-collection.mjs`, and keep the archive outside
the deployed `nft-collection` folder.

Archive created: 2026-10-18T16:57:21.784Z
